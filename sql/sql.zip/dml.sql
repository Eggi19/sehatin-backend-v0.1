\c moana_healthcare_db;

INSERT INTO admins (name, email, password) VALUES
('kayaba-san', 'kayawai@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.');

INSERT INTO genders (name) VALUES
    ('Male'),
    ('Female');

INSERT INTO doctor_specialists (name)
VALUES
('Sp. Kandungan & Kebidanan'),
('Sp. Kulit & Kelamin'),
('Sp. THT'),
('Sp. Jiwa'),
('Sp. Penyakit Dalam'),
('Sp. Anak'),
('Sp. Mata'),
('Dokter Gigi'),
('Dokter Umum'),
('Psikolog Klinis'),
('Sp. Saraf'),
('Sp. Paru'),
('Sp. Urologi'),
('Sp. Orthopaedi & Traumatologi'),
('Sp. Jantung & Pembuluh Darah'),
('Sp. PD Gastroenterologi - Hepatologi'),
('Sp. Bedah Umum'),
('Sp. Gizi Klinik'),
('Sp. PD Endokrin - Metabolik - Diabetes'),
('Sp. Andrologi'),
('Sp. Konservasi Gigi'),
('Dokter Bedah'),
('Sp. PD Ginjal - Hipertensi'),
('Sp. Gigi Anak'),
('Sp. Bedah Onkologi'),
('Sp. PD Reumatologi'),
('Sp. PD Hematologi & Onkologi Medik'),
('Sp. Bedah Mulut & Maksilofasial'),
('Sp. Bedah Saraf'),
('Sp. Rehabilitasi Medik & Kedokteran Fisik'),
('Sp. Ortodonsia'),
('Sp. Periodonsia'),
('Sp. Kedokteran Olahraga'),
('Psikolog Klinis Anak & Remaja'),
('Sp. PD Kardiovaskular'),
('Sp. Bedah Digestif'),
('Akupuntur'),
('Sp. Bedah Plastik'),
('Sp. Bedah Toraks Kardiovaskular'),
('Sp. Bedah Anak'),
('Fisioterapis'),
('Sp. Prostodonsia'),
('Sp. Bedah Vaskuler & Endovaskuler'),
('Sp. Penyakit Mulut'),
('Sp. PD Alergi - Imunologi'),
('Sp. PD Tropik - Infeksi'),
('Konselor Laktasi'),
('Sp. Bedah Spine'),
('Psikolog Klinis Dewasa'),
('Sp. Mikrobiologi Klinik'),
('Psikologi Industri dan Organisasi'),
('Sp. Bedah Panggul & Lutut'),
('Dokter Kecantikan'),
('Sp. Radiologi'),
('Sp. Anestesiologi'),
('Sp. Okupasi'),
('Sp. Onkologi Radiasi'),
('Sp. Patologi Anatomi'),
('Sp. Patologi Klinik'),
('Bidan'),
('Apoteker'),
('Dokter Forensik'),
('Dokter Umum (DU)'),
('Hipnoterapis'),
('Sp. Anak (Onkologi)'),
('Sp. Farmakologi Klinik'),
('Sp. Intervensi dan Kegawatdaruratan Napas'),
('Sp. Jiwa (Anak dan Remaja)'),
('Sp. Kedokteran Nuklir'),
('Sp. Nutrisi pada Kelainan Metabolisme'),
('Dokter Gigi Spesialis Radiologi - Subspesialis Radiodiagnosis Imaging'),
('Insurance'),
('Sp. Anak (Alergi-Imunologi Anak)'),
('Ahli Gizi'),
('Dokter Emergensi Medik'),
('Dokter Gigi Kosmetik'),
('Dokter Gigi Sp. Radiologi'),
('Dokter Hewan'),
('Haloskin'),
('Ilmu Biomedik'),
('Konselor'),
('Konsultasi Medis'),
('Lainnya'),
('Psikolog Non Klinis'),
('Sp. Anak (Gastroenterologi-Hepatologi)'),
('Sp. Anak (Nefrologi)'),
('Sp. Anak (Neonatologi)'),
('Sp. Anak (Neurologi)'),
('Sp. Anak (Nutrisi & Penyakit Metabolik)'),
('Sp. Anak (Penyakit Tropik-Infeksi)'),
('Sp. Anak (Tumbuh Kembang)'),
('Sp. Fetomaternal'),
('Sp. Gizi Klink (Konsultan Endokrin Metabolik)'),
('Sp. Jantung (Kardiologi Intervensi)'),
('Sp. Kedokteran Kelautan'),
('Sp. Kedokteran Keluarga Layanan Primer'),
('Sp. Kedokteran Penerbangan'),
('Sp. Kulit & Kelamin (Alergi-Imunologi)'),
('Sp. PD Geriatri'),
('Sp. PD Psikosomatik'),
('Sp. Saraf (Neuro-onkologi)'),
('Sp. THT (Bronko-Esofagologi)'),
('Spesialis Bedah Toraks Kardiak & Vaskular - Konsultan Vaskular EndoVaskular'),
('Spesialis Kedokteran Olahraga (Ahli Latihan dan Kompetisi)'),
('Spesialis Orthopedi Olahraga dan Artroskopi'),
('Spesialis Penyakit Dalam (Pulmonologi)'),
('Spesialis Saraf Konsultan Nyeri');

INSERT INTO users(name, email, password, birth_date, is_verified, is_google, is_online, gender_id, profile_picture) VALUES
('user 1', 'user1@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', '2020-02-01', true, false, false, 2, 'https://scontent-cgk1-1.xx.fbcdn.net/v/t31.18172-8/15585471_353802561653475_1837231782562759516_o.jpg?_nc_cat=102&ccb=1-7&_nc_sid=5f2048&_nc_ohc=-glCcI8keDkQ7kNvgEc7Xzb&_nc_ht=scontent-cgk1-1.xx&oh=00_AfBsFkJOf--GM_FZrliscQTfz636loyaRh8cvMUuNvGbZA&oe=66641BE7'),
('user 2', 'user2@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', '2020-02-01', true, false, false, 2, 'https://scontent-cgk1-1.xx.fbcdn.net/v/t31.18172-8/15585471_353802561653475_1837231782562759516_o.jpg?_nc_cat=102&ccb=1-7&_nc_sid=5f2048&_nc_ohc=-glCcI8keDkQ7kNvgEc7Xzb&_nc_ht=scontent-cgk1-1.xx&oh=00_AfBsFkJOf--GM_FZrliscQTfz636loyaRh8cvMUuNvGbZA&oe=66641BE7');

insert into user_addresses(city, city_id, province, address, district, sub_district, postal_code, is_main, user_id, coordinate) values 
('city 1', 1, 'prov 1', 'address 1', 'distric 1', 'subdis 1', 'postal 1', true, 1, ST_MakePoint(106.81098634803435, -6.226551042694845)),
('city 2', 2, 'prov 2', 'address 2', 'distric 2', 'subdis 2', 'postal 2', false, 1, ST_MakePoint(106.81425692473016, -6.2233650331214365));
insert into user_addresses(city, city_id, province, address, district, sub_district, postal_code, is_main, user_id, coordinate) values 
('city 1', 1, 'prov 1', 'address 1', 'distric 1', 'subdis 1', 'postal 1', true, 1, ST_MakePoint(106.81098634803435, -6.226551042694845)),
('city 2', 2, 'prov 2', 'address 2', 'distric 2', 'subdis 2', 'postal 2', false, 1, ST_MakePoint(106.81425692473016, -6.2233650331214365));

INSERT INTO doctors (name, email, password, is_verified, is_google, is_online, fee, certificate, work_start_year, doctor_specialists_id, profile_picture) VALUES
('doctor1', 'doctor1@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, false, 200000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2010, 1, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor2', 'doctor2@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, false, 200000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2012, 2, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor3', 'doctor3@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, false, 200000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2014, 3, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor4', 'doctor4@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, false, 200000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2016, 4, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor5', 'doctor5@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, false, 200000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2018, 5, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor6', 'doctor6@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, false, 200000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2020, 6, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor7', 'doctor7@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN72eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, false, 200000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2021, 7, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor8', 'doctor8@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN82eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, false, 200000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2022, 8, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor9', 'doctor9@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN92eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, false, 200000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2023, 9, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor10', 'doctor10@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN102eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, false, 200000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2024, 10, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor11', 'doctor11@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', false, true, true, 300000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2000, 1, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor12', 'doctor12@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', false, true, true, 300000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2002, 2, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor13', 'doctor13@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', false, true, true, 300000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2004, 3, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor14', 'doctor14@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', false, true, true, 300000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2006, 4, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor15', 'doctor15@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', false, true, true, 300000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2008, 5, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor16', 'doctor16@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', false, true, true, 300000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2000, 6, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor17', 'doctor17@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN72eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', false, true, true, 300000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2001, 7, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor18', 'doctor18@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN82eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', false, true, true, 300000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2002, 8, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor19', 'doctor19@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN92eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', false, true, true, 300000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2003, 9, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor20', 'doctor20@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN102eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', false, true, true, 300000, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2004, 10, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor21', 'doctor21@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, true, 2, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2011, 11, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor22', 'doctor22@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, true, 2, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2012, 12, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor23', 'doctor23@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, true, 2, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2013, 13, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor24', 'doctor24@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, true, 2, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2014, 14, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor25', 'doctor25@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, true, 2, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2015, 15, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor26', 'doctor26@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, true, 2, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2016, 16, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor27', 'doctor27@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN72eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, true, 2, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2017, 17, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor28', 'doctor28@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN82eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, true, 0, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2018, 18, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor29', 'doctor29@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN92eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, true, 0, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2019, 19, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D'),
('doctor30', 'doctor30@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN102eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.', true, false, true, 0, 'https://res.cloudinary.com/deu2djyxi/image/upload/v1715227365/d3rroj03uoqgkqrgguoc.pdf', 2020, 10, 'https://scontent-cgk1-2.xx.fbcdn.net/v/t31.18172-8/19477396_448769845490079_5241421480734158825_o.jpg?_nc_cat=109&ccb=1-7&_nc_sid=5f2048&_nc_ohc=cr77wNDG_nkQ7kNvgHsBhBt&_nc_ht=scontent-cgk1-2.xx&oh=00_AfCSYAfe1gxhR5t9uv2dg3PL8TynuDo2wCoAPnY6rrvuyw&oe=665AE95D');

INSERT INTO admins (name, email, password)
VALUES ('admin1', 'admin@mail.com', '$2y$10$lRjllBSRaFJ0hA1moCN62eeQ8ABumbo8hOVcyDTQYINpgYeNlHEX.');

INSERT INTO official_shipping_methods (name, fee) VALUES
    ('Official Instant', 2500),
    ('Official SameDay', 1000);

INSERT INTO non_official_shipping_methods (name, courier, service, description) VALUES
    ('Citra Van Titipan Kilat (TIKI)', 'tiki', 'ONS', 'Over Night Service'),
    ('Jalur Nugraha Ekakurir (JNE)', 'jne', 'YES', 'Yakin Esok Sampai');

INSERT INTO order_statuses(name) VALUES
	('Pending'),
	('Processing'),
	('Shipped'),
	('Completed'),
	('Canceled');

INSERT INTO mutation_statuses (id, name) VALUES
    (1, 'processed'),
    (2, 'canceled'),
    (3, 'pending');