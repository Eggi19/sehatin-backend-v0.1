\c postgres

DROP DATABASE IF EXISTS moana_healthcare_db; 
CREATE DATABASE moana_healthcare_db;

\c moana_healthcare_db;

CREATE EXTENSION postgis;

CREATE TABLE admins (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    email VARCHAR NOT NULL,
    UNIQUE(email),
    password VARCHAR NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP
);

CREATE TABLE doctor_specialists (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP
);

CREATE TABLE genders (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP
);

CREATE TABLE order_statuses (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP
);

CREATE TABLE official_shipping_methods (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    fee INT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP
);

CREATE TABLE non_official_shipping_methods (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    courier VARCHAR NOT NULL,
    service VARCHAR NOT NULL,
    description VARCHAR NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP
);

CREATE TABLE categories (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP
);

CREATE TABLE pharmacy_managers (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    email VARCHAR NOT NULL,
    UNIQUE(email),
    password VARCHAR NOT NULL,
    phone_number VARCHAR NOT NULL,
    logo VARCHAR NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP
);


CREATE TABLE manufactures (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP
);

CREATE TABLE product_forms (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP
);

CREATE TABLE product_classifications (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP
);

CREATE TABLE mutation_statuses (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP
);

CREATE TABLE doctors (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    email VARCHAR NOT NULL,
    UNIQUE(email),
    password VARCHAR,
    is_verified BOOLEAN NOT NULL DEFAULT false,
    is_google BOOLEAN NOT NULL DEFAULT false,
    is_online BOOLEAN NOT NULL DEFAULT false,
    fee INT,
    certificate VARCHAR,
    work_start_year INT,
    profile_picture VARCHAR,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    doctor_specialists_id BIGINT,
    FOREIGN KEY (doctor_specialists_id) REFERENCES doctor_specialists(id)
);

CREATE TABLE doctor_reset_password_tokens (
    id BIGSERIAL PRIMARY KEY,
    token VARCHAR NOT NULL,
    expired_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    doctor_id BIGINT NOT NULL,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id)
);

CREATE TABLE doctor_verification_tokens (
    id BIGSERIAL PRIMARY KEY,
    token VARCHAR NOT NULL,
    expired_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    doctor_id BIGINT NOT NULL,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id)
);

CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    email VARCHAR NOT NULL,
    UNIQUE(email),
    password VARCHAR,
    birth_date DATE,
    is_verified BOOLEAN NOT NULL DEFAULT false,
    is_google BOOLEAN NOT NULL DEFAULT false,
    is_online BOOLEAN NOT NULL DEFAULT false,
    profile_picture VARCHAR,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    gender_id BIGINT,
    FOREIGN KEY (gender_id) REFERENCES genders(id)
);

CREATE TABLE user_reset_password_tokens (
    id BIGSERIAL PRIMARY KEY,
    token VARCHAR NOT NULL,
    expired_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    user_id BIGINT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE user_verification_tokens (
    id BIGSERIAL PRIMARY KEY,
    token VARCHAR NOT NULL,
    expired_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    user_id BIGINT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE user_addresses (
    id BIGSERIAL PRIMARY KEY,
    city VARCHAR NOT NULL,
    city_id SMALLINT NOT NULL,
    province VARCHAR NOT NULL,
    address VARCHAR NOT NULL,
    district VARCHAR NOT NULL,
    sub_district VARCHAR NOT NULL,
    postal_code VARCHAR NOT NULL,
    coordinate GEOGRAPHY NOT NULL,
    is_main BOOLEAN NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    user_id BIGINT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE INDEX ON user_addresses USING gist(coordinate);

CREATE TABLE consultations (
	id BIGSERIAL PRIMARY KEY,
	patient_name VARCHAR NOT NULL,
	patient_birth_date VARCHAR NOT NULL,
	certificate_url VARCHAR,
    prescription_url VARCHAR,
	ended_at TIMESTAMP,
	created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
	doctor_id BIGINT NOT NULL,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id),
	user_id BIGINT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
	patient_gender_id BIGINT NOT NULL,
    FOREIGN KEY (patient_gender_id) REFERENCES genders(id)
);

CREATE TABLE chats (
	id BIGSERIAL PRIMARY KEY,
    is_from_user BOOLEAN NOT NULL,
    content VARCHAR NOT NULL,
    type VARCHAR NOT NULL,
	created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    consultation_id BIGINT NOT NULL,
    FOREIGN KEY (consultation_id) REFERENCES consultations(id)
);

CREATE TABLE products (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    generic_name VARCHAR NOT NULL,
    content VARCHAR NOT NULL,
    description VARCHAR NOT NULL,
    unit_in_pack VARCHAR NOT NULL,
    selling_unit VARCHAR NOT NULL,
    weight SMALLINT NOT NULL,
    height SMALLINT NOT NULL,
    length SMALLINT NOT NULL,
    width SMALLINT NOT NULL,
    product_picture VARCHAR NOT NULL,
    slug_id VARCHAR NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    product_form_id BIGINT NOT NULL,
    FOREIGN KEY (product_form_id) REFERENCES product_forms(id),
    product_classification_id BIGINT NOT NULL,
    FOREIGN KEY (product_classification_id) REFERENCES product_classifications(id),
    manufacture_id BIGINT NOT NULL,
    FOREIGN KEY (manufacture_id) REFERENCES manufactures(id),
    UNIQUE (name, generic_name, content, manufacture_id)
);

CREATE TABLE product_categories (
    id BIGSERIAL PRIMARY KEY,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    product_id BIGINT NOT NULL,
    FOREIGN KEY (product_id) REFERENCES products(id),
    category_id BIGINT NOT NULL,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE pharmacies (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR NOT NULL,
    operational_hour VARCHAR NOT NULL,
    operational_day VARCHAR NOT NULL,
    pharmacist_name VARCHAR NOT NULL,
    pharmacist_license_number VARCHAR NOT NULL,
    pharmacist_phone_number VARCHAR NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    pharmacy_manager_id BIGINT NOT NULL,
    FOREIGN KEY (pharmacy_manager_id) REFERENCES pharmacy_managers(id),
    UNIQUE(name)
);

CREATE TABLE pharmacies_shipping_methods (
    id BIGSERIAL PRIMARY KEY,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    official_id BIGINT,
    FOREIGN KEY (official_id) REFERENCES official_shipping_methods(id),
    non_official_id BIGINT,
    FOREIGN KEY (non_official_id) REFERENCES non_official_shipping_methods(id),
    pharmacy_id BIGINT NOT NULL,
    FOREIGN KEY (pharmacy_id) REFERENCES pharmacies(id)
);

CREATE TABLE pharmacy_addresses (
    id BIGSERIAL PRIMARY KEY,
    city VARCHAR NOT NULL,
    city_id SMALLINT NOT NULL,
    province VARCHAR NOT NULL,
    address VARCHAR NOT NULL,
    district VARCHAR NOT NULL,
    sub_district VARCHAR NOT NULL,
    postal_code VARCHAR NOT NULL,
    coordinate GEOGRAPHY NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    pharmacy_id BIGINT NOT NULL,
    FOREIGN KEY (pharmacy_id) REFERENCES pharmacies(id),
    UNIQUE (pharmacy_id)
);

CREATE INDEX ON pharmacy_addresses USING gist(coordinate);

CREATE TABLE pharmacy_products (
    id BIGSERIAL PRIMARY KEY,
    price INT NOT NULL,
    total_stock INT NOT NULL,
    is_available BOOLEAN NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    product_id BIGINT NOT NULL,
    FOREIGN KEY (product_id) REFERENCES products(id),
    pharmacy_id BIGINT NOT NULL,
    FOREIGN KEY (pharmacy_id) REFERENCES pharmacies(id)
);

CREATE TABLE stock_histories (
    id BIGSERIAL PRIMARY KEY,
    quantity SMALLINT NOT NULL,
    description VARCHAR NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    pharmacy_product_id BIGINT NOT NULL,
    FOREIGN KEY (pharmacy_product_id) REFERENCES pharmacy_products(id),
    pharmacy_id BIGINT,
    FOREIGN KEY (pharmacy_id) REFERENCES pharmacies(id)
);

CREATE TABLE stock_transfer_requests (
    id BIGSERIAL PRIMARY KEY,
    quantity SMALLINT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    mutation_status_id BIGINT NOT NULL,
    FOREIGN KEY (mutation_status_id) REFERENCES mutation_statuses(id),
    pharmacy_sender_id BIGINT,
    FOREIGN KEY (pharmacy_sender_id) REFERENCES pharmacies(id),
    pharmacy_receiver_id BIGINT,
    FOREIGN KEY (pharmacy_receiver_id) REFERENCES pharmacies(id),
    product_id BIGINT,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE prescription_items (
    id BIGSERIAL PRIMARY KEY,
    quantity INT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    consultation_id BIGINT NOT NULL,
    FOREIGN KEY (consultation_id) REFERENCES consultations(id),
    product_id BIGINT NOT NULL,
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE cart_items (
    id BIGSERIAL PRIMARY KEY,
    quantity INT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    user_id BIGINT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    pharmacy_product_id BIGINT NOT NULL,
    FOREIGN KEY (pharmacy_product_id) REFERENCES pharmacy_products(id)
);

CREATE TABLE orders (
    id BIGSERIAL PRIMARY KEY,
    order_number VARCHAR NOT NULL,
    UNIQUE(order_number),
    total_price INT NOT NULL,
    payment_proof VARCHAR,
    payment_deadline TIMESTAMP NOT NULL,
    shipping_fee INT NOT NULL,
    shipping_method VARCHAR NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    user_address_id BIGINT NOT NULL,
    FOREIGN KEY (user_address_id) REFERENCES user_addresses(id),
    order_status_id BIGINT NOT NULL,
    FOREIGN KEY (order_status_id) REFERENCES order_statuses(id),
    pharmacy_id BIGINT NOT NULL,
    FOREIGN KEY (pharmacy_id) REFERENCES pharmacies(id)
);

CREATE TABLE order_items (
    id BIGSERIAL PRIMARY KEY,
    quantity SMALLINT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    order_id BIGINT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    pharmacy_product_id BIGINT NOT NULL,
    FOREIGN KEY (pharmacy_product_id) REFERENCES pharmacy_products(id)
);

CREATE TABLE stock_history_reports (
    id BIGSERIAL PRIMARY KEY,
    total_addition INT NOT NULL,
    total_deduction INT NOT NULL,
    final_stock INT NOT NULL,
    pharmacy_product_id BIGINT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
    deleted_at TIMESTAMP,
    FOREIGN KEY (pharmacy_product_id) REFERENCES pharmacy_products(id)
);